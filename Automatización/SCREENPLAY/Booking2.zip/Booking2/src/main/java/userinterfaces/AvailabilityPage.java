package userinterfaces;

public class AvailabilityPage {
}
