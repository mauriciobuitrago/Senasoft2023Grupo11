package userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

import java.net.PortUnreachableException;

public class ReservationPage {



    public static final Target BTN_RESERVAPARTAMENTO = Target.the("click in the button reservation apartm ")
            .locatedBy("//span[@class='bui-button__tex'");

    public static final Target BTN_RESERVARE = Target.the("click in the button reservare for reservation in the apartm")
            .locatedBy("//a[class=´txp-group-cta bui-button bui-button--primary bui-button--large bui-button--wide \n" +
                    "js-group-recommendation-reserve-btn\n'");
}


