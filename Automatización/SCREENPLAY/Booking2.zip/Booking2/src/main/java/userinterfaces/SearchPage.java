package userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class SearchPage {

    public static final Target BTN_BUSCAR = Target.the("click in the button search ")
            .locatedBy("//button[@type='submit'");
}
