package userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class FilterPage {

    public static final Target BTN_CHECKIN = Target.the("select the check-in")
            .locatedBy("//span[@class='cf06f772fa e4862a187f a8b15b729e'");

    public static final Target BTN_CHECKOUT = Target.the("select the check-out")
            .locatedBy("/span[@claas=´ccb65902b2'");


    public static final Target BTN_NUMDORMITORIOS = Target.the("Used to choose the number of bedrooms")
            .locatedBy("//button[@arai-hidden='true']");

    public static final Target BTN_PERSONAS = Target.the("Selection of people for the reservation")
            .locatedBy("//button[@type='button']");

    public static final Target BTN_ADULTOS = Target.the("Select the number of adults for the reservation.")
            .locatedBy("//label[@fot='group_adults']");

    public static final Target BTN_NIÑOS = Target.the("select the number of children for the reservation")
            .locatedBy("//label[@fot='group_children']");

    public static final Target BTN_EDAD = Target.the("select the age of the child")
            .locatedBy("//select[@class='ebf4591cBe']");

    public static  final Target BTN_EDAD1 = Target.the("select the age of the child")
            .locatedBy("select[@class='ebf4591c8e'");


    public static final Target BTN_ESTRELLAS = Target.the("select number for stars")
            .locatedBy("//<svg[@xmlns='http://www.w3.org/2000/svg'");

    public static final Target BTN_PRECIO = Target.the("select the value to the pay")
            .locatedBy("//div[@class= 'b18036920b'");

}
