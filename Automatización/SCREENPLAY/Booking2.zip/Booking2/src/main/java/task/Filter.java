package task;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import userinterfaces.FilterPage;
import userinterfaces.ReservationPage;

public class Filter implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
      actor.attemptsTo(Click.on(FilterPage.BTN_NUMDORMITORIOS));
        actor.attemptsTo(Click.on(FilterPage.BTN_PERSONAS));
        actor.attemptsTo(Click.on(FilterPage.BTN_ADULTOS));
        actor.attemptsTo(Click.on(FilterPage.BTN_CHECKIN));
        actor.attemptsTo(Click.on(FilterPage.BTN_CHECKOUT));
}
    public static Filter enter()
    {
        return Tasks.instrumented(Filter.class);

    }

}

