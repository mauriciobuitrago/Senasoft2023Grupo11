package task;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import userinterfaces.ReservationPage;

public class Reservation implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {


        actor.attemptsTo(Click.on(ReservationPage.BTN_RESERVAPARTAMENTO));
        actor.attemptsTo(Click.on(ReservationPage.BTN_RESERVARE));
    }

    public static Reservation enter()
    {
        return Tasks.instrumented(Reservation.class);

    }

   }
