package task;

public class Availability {
}
