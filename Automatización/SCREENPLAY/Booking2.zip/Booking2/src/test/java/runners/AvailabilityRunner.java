package runners;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = "src/test/resources/features/availability.feature",
        snippets = SnippetType.CAMELCASE,
        glue = "com.co.booking.stepsdefinitions"
)

public class AvailabilityRunner {






    @Given("^the user is on the Booking\\.com website$")
    public void theUserIsOnTheBookingComWebsite() {

    }


    @When("^they can view the accommodation availability$")
    public void theyCanViewTheAccommodationAvailability() {

    }

    @Then("^they should have access to the booking opt$")
    public void theyShouldHaveAccessToTheBookingOpt() {
    }

}
