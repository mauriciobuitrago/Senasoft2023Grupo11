package stepsdefinitions;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.Cast;
import net.serenitybdd.screenplay.actors.OnStage;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;
import task.Reservation;

public class SearchStepDefinition {

    @Managed
    WebDriver hisBrowser;

    @Before
    public void sepUp(){
        OnStage.setTheStage(Cast.ofStandardActors());
        OnStage.theActorCalled("User");
        OnStage.theActorInTheSpotlight().can(BrowseTheWeb.with(hisBrowser));

    }

    @Given ("^the user is on the Booking\\.com website$")
    public void theUserIsOnTheBookingComWebsite() {
        OnStage.theActorInTheSpotlight().wasAbleTo(Open.url("https://www.booking.com/searchresults.es.html?ss=Pasto%2C+Nari%C3%B1o%2C+Colombia&ssne=Playa+Venao&ssne_untouched=Playa+Venao&efdco=1&label=es-co-booking-desktop-vjGZbEFOhRc3a9njxeT3IwS652829002024%3Apl%3Ata%3Ap1%3Ap2%3Aac%3Aap%3Aneg%3Afi%3Atikwd-65526620%3Alp1003665%3Ali%3Adec%3Adm&aid=2311236&lang=es&sb=1&src_elem=sb&src=index&dest_id=-594525&dest_type=city&ac_position=0&ac_click_type=b&ac_langcode=es&ac_suggestion_list_length=5&search_selected=true&search_pageview_id=4b0e99e5242603dd&ac_meta=GhA0YjBlOTllNTI0MjYwM2RkIAAoATICZXM6BXBhc3RvQABKAFAA&checkin=2023-11-16&checkout=2023-11-17&group_adults=2&no_rooms=1&group_children=0&sb_travel_purpose=leisure"));
    }


    @When ("^the user can access the accommodation search bar$")
    public void theUserCanAccessTheAccommodationSearchBar() {

        OnStage.theActorInTheSpotlight().attemptsTo(Reservation.enter());
    }

    @Then ("^the user will be able to enter the text they want$")
    public void theUserWillBeAbleToEnterTheTextTheyWant() {

    }

}
