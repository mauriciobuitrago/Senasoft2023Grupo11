package stepsdefinitions;

public class AvailabilityStepDefinition {
}
