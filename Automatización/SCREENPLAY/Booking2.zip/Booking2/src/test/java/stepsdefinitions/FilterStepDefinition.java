package stepsdefinitions;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actors.Cast;
import net.serenitybdd.screenplay.actors.OnStage;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;

public class FilterStepDefinition  {
    @Managed
    WebDriver hisBrowser;

    @Before
    public void sepUp(){
        OnStage.setTheStage(Cast.ofStandardActors());
        OnStage.theActorCalled("User");
        OnStage.theActorInTheSpotlight().can(BrowseTheWeb.with(hisBrowser));

    }
    @Given("^that the user is on the Booking\\.com website$")
    public void thatTheUserIsOnTheBookingComWebsite() {

    }

    @Given("^has performed a search in the accommodation section$")
    public void hasPerformedASearchInTheAccommodationSection() {

    }

    @When("^you can view the filter categories$")
    public void youCanViewTheFilterCategories() {

    }

    @Then("^the user will be able to select an available category\\(s\\)$")
    public void theUserWillBeAbleToSelectAnAvailableCategoryS() {

    }

}
